eexport default async function handler(req, res) {
  const code = req.query.code;

  if (!code) {
    return res.status(400).json({ error: "Missing authorization code" });
  }

  const client_id = "103117486441-6vakflis9n8bb9h2kpt43mdtscsgg3o5.apps.googleusercontent.com";
  const client_secret = "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";
  const redirect_uri = "https://replyai-vercel-seven.vercel.app/api/exchange-token";

  try {
    const tokenRes = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        code,
        client_id,
        client_secret,
        redirect_uri,
        grant_type: "authorization_code",
      }),
    });

    const tokenData = await tokenRes.json();
    return res.status(200).json(tokenData);
  } catch (err) {
    return res.status(500).json({ error: "Token exchange failed", details: err.message });
  }
}
